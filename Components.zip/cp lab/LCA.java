import java.util.*;
class BinaryTreeNode {
    public int data;
    public BinaryTreeNode left, right;
    public BinaryTreeNode(int data) {
        this.data = data;
        left = null;
        right = null;
    }
}
class LowestCommonAncestor {
    public BinaryTreeNode lowestCommonAncestor(BinaryTreeNode root,BinaryTreeNode p,BinaryTreeNode q) {
        if (root == null || root == p || root == q)
            return root;
        BinaryTreeNode left =lowestCommonAncestor(root.left, p, q);
        BinaryTreeNode right =lowestCommonAncestor(root.right, p, q);
        return left == null? right: right == null? left: root;
    }
}
public class LCA {
    static BinaryTreeNode root;
    static BinaryTreeNode temp = root;
    void insert(BinaryTreeNode temp, int key) {
        if (temp == null) {
            root = new BinaryTreeNode(key);
            return;
        }
        Queue<BinaryTreeNode> q =new LinkedList<BinaryTreeNode>();
        q.add(temp);
        while (!q.isEmpty()) {
            temp = q.peek();
            q.remove();
            if (temp.left == null) {
                temp.left =new BinaryTreeNode(key);
                break;
            } else {
                q.add(temp.left);
            }
            if (temp.right == null) {
                temp.right =new BinaryTreeNode(key);
                break;
            } else {
                q.add(temp.right);
            }
        }
    }
    public static BinaryTreeNode findNode(BinaryTreeNode root,int key) {
        if (root == null)
            return null;
        if (root.data == key)
            return root;
        BinaryTreeNode left =findNode(root.left, key);
        if (left != null)
            return left;
        return findNode(root.right, key);
    }
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        String str[] =sc.nextLine().split(" ");
        LCA lca = new LCA();
        root =new BinaryTreeNode(Integer.parseInt(str[0]));
        for (int i = 1; i < str.length; i++)
            lca.insert(root,Integer.parseInt(str[i]));
        int p = sc.nextInt();
        int q = sc.nextInt();
        BinaryTreeNode node1 =findNode(root, p);
        BinaryTreeNode node2 =findNode(root, q);
        LowestCommonAncestor sol =new LowestCommonAncestor();
        BinaryTreeNode res =sol.lowestCommonAncestor(root,node1,node2);
        System.out.println(res.data);
    }
}
